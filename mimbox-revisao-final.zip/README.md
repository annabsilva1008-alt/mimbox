# Mimbox

Loja estática com funções serverless na Vercel, catálogo e CRM no Supabase e pagamento InfinitePay.

## Validação

Execute `node tests/checkout.mjs` (Node 20+). Os serviços externos são simulados: o teste não cria pedidos nem cobranças reais. Verifica registro antes do pagamento, preços do servidor, frete, Clube, preferências e falhas de registro.

## Catálogo e publicação

O catálogo público continua em `/api/admin-produtos?publico=1`. O painel mantém preços e disponibilidade; botões de compra de produtos só são criados após a consulta. Conteúdo editorial das páginas de `/colecoes/` e links estáticos da home precisam acompanhar mudanças de nome, fotos ou novas coleções no painel. Os preços e disponibilidade usados para comprar são consultados ao abrir a página e revalidados no checkout.

Planos legados: 3 meses R$ 299,90 e 6 meses R$ 549,90. Quando houver um plano no catálogo, seu ID e preço do CRM são usados. Mantenha preços legados e cartões de assinatura sincronizados ao alterar planos. Frete incluso para carrinhos compostos apenas por planos, ou compras acima de R$ 300. O endpoint de cotação recebe `subtotal` em centavos.

O checkout registra cliente e pedido pendente antes de gerar o link InfinitePay. Preferências do Clube são guardadas em `pedidos.observacoes`. A confirmação financeira continua no webhook e depende da validação da transação na InfinitePay; voltar à página de retorno não confirma pagamento.

## SEO

`robots.txt`, `sitemap.xml`, canonical e metadados sociais. Cada coleção tem URL própria, conteúdo HTML e dados estruturados de produto. Ofertas são preenchidas com o catálogo ao vivo, sem avaliações fictícias. Páginas de painel, retorno e testes têm `noindex`.

## Operação

As variáveis existentes `SUPABASE_URL`, `SUPABASE_SECRET_KEY` e `MELHOR_ENVIO_TOKEN` permanecem no servidor. Nenhuma chave deve ser colocada no HTML. A configuração pública da loja respondeu 503 na revisão de 16/10/2026; o site mantém os dados de atendimento e retirada já existentes no HTML.

Identificação fiscal/razão social e canal de e-mail devem ser completados com dados reais fornecidos pela responsável. Não foram inventados documentos, avaliações, certificados ou selos.
