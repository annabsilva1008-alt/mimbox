
    const observer = new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('in-view');observer.unobserve(entry.target)}}),{threshold:.2});
    document.querySelectorAll('.intro-card').forEach(card=>observer.observe(card));
    