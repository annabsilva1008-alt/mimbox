(() => {
  const nav = document.querySelector('.navlinks');
  if (nav) {
    const menu = document.createElement('details'); menu.className='mobile-nav';
    menu.innerHTML='<summary aria-label="Abrir menu de navegação">Menu ☰</summary><div><a href="/#boxes">Nossas boxes</a><a href="/#assinatura">Clube Mimbox</a><a href="/#sobre">A Mimbox</a><a href="/atendimento.html">Atendimento</a><a href="/entregas-e-trocas.html">Entregas e devoluções</a></div>';
    nav.prepend(menu);menu.addEventListener('click',e=>{if(e.target.closest('a'))menu.open=false});
  }
  const form=document.getElementById('cart-checkout-form');
  const total=document.getElementById('checkout-totals');
  const money=n=>new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(n);
  function updateTotals(){
    if(!form||!total)return;
    const subtotal=document.getElementById('cart-subtotal').textContent;
    const pickup=form.elements.deliveryMethod.value==='pickup';
    const selected=form.querySelector('input[name="freight-service"]:checked');
    const freight=pickup?'Grátis — retirada':selected?selected.parentElement.textContent.trim():'Calcule e selecione a entrega abaixo';
    total.replaceChildren();
    for(const text of ['Produtos: '+subtotal,'Entrega: '+freight]){const p=document.createElement('p');p.textContent=text;total.append(p)}
    if(pickup||selected){
      const value=pickup?0:Number((selected.parentElement.textContent.match(/R\$\s*([\d.,]+)/)||[])[1]?.replace(/\./g,'').replace(',','.'));
      const productValue=Number(subtotal.replace(/[^\d,]/g,'').replace(',','.'));
      if(Number.isFinite(value)&&Number.isFinite(productValue)){const p=document.createElement('p');const strong=document.createElement('strong');strong.textContent='Total estimado: '+money(productValue+value);p.append(strong);total.append(p)}
    }
  }
  if(form){form.addEventListener('change',updateTotals);form.addEventListener('input',updateTotals);new MutationObserver(updateTotals).observe(document.getElementById('cart-subtotal'),{childList:true,subtree:true});new MutationObserver(updateTotals).observe(document.getElementById('freight-results'),{childList:true});updateTotals()}
  document.addEventListener('mimbox:catalog-ready',e=>{
    const p=e.detail.find(p=>String(p.id)===document.body.dataset.productId);
    if(!p)return;
    // Schema offers follow the live CRM price and availability.
    const schema={'@context':'https://schema.org','@type':'Product',name:p.nome,sku:p.id,image:p.imagens,brand:{'@type':'Brand',name:'Mimbox'},offers:{'@type':'Offer',priceCurrency:'BRL',price:Number(p.preco).toFixed(2),availability:p.disponivel?'https://schema.org/InStock':'https://schema.org/OutOfStock',url:document.querySelector('link[rel="canonical"]').href}};
    const scripts=[...document.querySelectorAll('script[type="application/ld+json"]')];
    const el=scripts.find(s=>{try{return JSON.parse(s.textContent)['@type']==='Product'}catch{return false}});
    if(el)el.textContent=JSON.stringify(schema);
  });
})();
