
/* Catálogo público: produtos e clubes cadastrados no CRM.
   Preserva as artes legadas enquanto não houver imagem no CRM.
   Não modifica a API de pagamento nem cria registros no banco. */
(() => {
  const PRODUCT_PATHS = {"72eae3cd-e308-4971-a5c8-4448d105487e": "/colecoes/brasilidades.html", "cc822350-b66b-445b-8292-c81a88e897ba": "/colecoes/natal.html", "82576ed6-b69c-4908-bef2-111c7f29a302": "/colecoes/japa.html", "980a6c98-7ffd-4d87-b42a-923f89038ff1": "/colecoes/pe-na-areia.html", "0820cba6-5332-4214-baa5-34aa85c8b732": "/colecoes/mim-cine.html", "06ce9d96-47c1-41de-9a07-128af0755b75": "/colecoes/vsf.html", "36374c1e-d863-49e7-a1da-8342587c90f4": "/colecoes/horoscopo-de-boteco.html"};
  const norm = v => String(v ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
  const money = n => new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(n);
  const price = v => v !== null && v !== '' && Number.isFinite(Number(v)) && Number(v) >= 0 ? Number(v) : null;
  const safeImg = v => typeof v === 'string' && /^https:\/\//i.test(v);
  const grid = document.querySelector('.collection-grid');
  const plans = document.querySelector('.subscription .plans');
  if (!grid) return;
  const legacyCards = [...grid.querySelectorAll('.product-card')];
  const legacyNames = new Map(legacyCards.map(card => [norm(card.querySelector('.product-info h3')?.textContent),card]));
  const isClub = p => /clube|assinatura/.test(norm(p.colecao)) || /clube mimbox/.test(norm(p.nome));
  const months = p => {const s=norm(p.nome+' '+p.colecao); return /(^| )3( |$)|tres meses/.test(s)?3:/(^| )6( |$)|seis meses/.test(s)?6:/9 meses/.test(s)?9:0};
  // Galeria visual: apenas lê fotos do CRM. Não altera cadastro, API ou carrinho.
  const reducedMotion=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let activeModal=null;
  function openPhotoViewer(urls,initial,name){
    if(activeModal)activeModal.remove();
    const overlay=document.createElement('div');overlay.className='mimbox-photo-overlay';
    overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');
    overlay.setAttribute('aria-label','Fotos ampliadas de '+name);
    const photo=document.createElement('img');photo.className='mimbox-photo-full';
    photo.alt=name;
    const close=document.createElement('button');close.type='button';close.className='mimbox-photo-close';close.textContent='×';close.setAttribute('aria-label','Fechar fotos');
    const previous=document.createElement('button');previous.type='button';previous.className='mimbox-photo-back';previous.textContent='‹';previous.setAttribute('aria-label','Foto anterior');
    const following=document.createElement('button');following.type='button';following.className='mimbox-photo-forward';following.textContent='›';following.setAttribute('aria-label','Próxima foto');
    const counter=document.createElement('span');counter.className='mimbox-photo-counter';
    let pos=initial;
    function render(){photo.src=urls[pos];photo.alt=name+' — foto '+(pos+1)+' de '+urls.length;counter.textContent=(pos+1)+' / '+urls.length}
    function step(delta){pos=(pos+delta+urls.length)%urls.length;render()}
    const oldOverflow=document.body.style.overflow;
    function dismiss(){overlay.remove();document.body.style.overflow=oldOverflow;document.removeEventListener('keydown',keyboard);activeModal=null}
    function keyboard(e){if(e.key==='Escape')dismiss();else if(e.key==='ArrowRight')step(1);else if(e.key==='ArrowLeft')step(-1)}
    close.addEventListener('click',dismiss);
    overlay.addEventListener('click',e=>{if(e.target===overlay)dismiss()});
    previous.addEventListener('click',()=>step(-1));following.addEventListener('click',()=>step(1));
    overlay.append(photo,close,counter);
    if(urls.length>1)overlay.append(previous,following);
    document.body.append(overlay);document.body.style.overflow='hidden';
    document.addEventListener('keydown',keyboard);activeModal=overlay;render();close.focus();
  }
  function gallery(card,p){
    const art=card.querySelector('.product-art');if(!art)return;
    const urls=[...(Array.isArray(p.imagens)?p.imagens:[]),p.imagem_url]
      .filter(safeImg).map(u=>u.trim());
    const unique=[...new Set(urls)].slice(0,8);
    if(!unique.length)return;
    const oldImg=art.querySelector('img');
    const fallback=oldImg?.getAttribute('src')||'';
    art.replaceChildren();art.classList.add('mimbox-gallery');
    const img=document.createElement('img');img.src=unique[0];img.alt='Foto 1 de '+unique.length+' — '+p.nome;
    img.width=600;img.height=600;img.loading=document.body.dataset.productId?'eager':'lazy';img.decoding='async';img.className='mimbox-product-photo';
    img.addEventListener('error',()=>{if(fallback&&!img.dataset.fallback){img.dataset.fallback='1';img.src=fallback}else img.style.visibility='hidden'});
    art.append(img);
    let index=0,timer=null,visible=false;
    const count=document.createElement('span');count.className='mimbox-gallery-count';art.append(count);
    const zoom=document.createElement('button');zoom.type='button';zoom.className='mimbox-gallery-zoom';zoom.setAttribute('aria-label','Ampliar fotos de '+p.nome);zoom.textContent='⤢';art.append(zoom);
    function show(i){index=(i+unique.length)%unique.length;img.style.visibility='visible';img.removeAttribute('data-fallback');img.src=unique[index];img.alt='Foto '+(index+1)+' de '+unique.length+' — '+p.nome;count.textContent=(index+1)+' / '+unique.length}
    function stop(){if(timer){clearInterval(timer);timer=null}}
    function start(){} // As fotos mudam apenas quando o cliente escolhe.
    function manual(delta){show(index+delta);stop();start()}
    zoom.addEventListener('click',e=>{e.stopPropagation();stop();openPhotoViewer(unique,index,p.nome)});
    img.addEventListener('click',()=>{stop();openPhotoViewer(unique,index,p.nome)});
    if(unique.length>1){
      const prev=document.createElement('button');prev.type='button';prev.className='mimbox-gallery-arrow mimbox-gallery-prev';prev.textContent='‹';prev.setAttribute('aria-label','Foto anterior de '+p.nome);
      const next=document.createElement('button');next.type='button';next.className='mimbox-gallery-arrow mimbox-gallery-next';next.textContent='›';next.setAttribute('aria-label','Próxima foto de '+p.nome);
      prev.addEventListener('click',e=>{e.stopPropagation();manual(-1)});next.addEventListener('click',e=>{e.stopPropagation();manual(1)});
      art.append(prev,next);
      art.addEventListener('mouseenter',stop);art.addEventListener('mouseleave',start);
      art.addEventListener('focusin',stop);art.addEventListener('focusout',start);
      const observer=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;if(visible)start();else stop()},{threshold:.25});observer.observe(art);
      document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();else start()});
    }else count.style.display='none';
    show(0);
  }
  function updateCard(card,p){
    const info=card.querySelector('.product-info'); const btn=card.querySelector('.add-to-cart');if(!info||!btn)return;
    const displayName = /horoscopo/i.test(norm(p.colecao)) ? p.colecao : p.nome;
    const title=info.querySelector('h3,h2');if(title)title.textContent=displayName;
    card.id='produto-'+p.id;
    const amount=price(p.preco);
    if(amount!==null){const el=info.querySelector('.sample-price');if(el)el.textContent=money(amount);btn.dataset.productPrice=amount.toFixed(2)}
    const desc=info.querySelector('p');if(desc&&p.descricao)desc.textContent=p.descricao;
    btn.dataset.productName=p.nome;
    // Existing product IDs remain unchanged to preserve checkout mapping.
    if(!card.dataset.legacyProduct && p.id!=null)btn.dataset.productId=String(p.id);
    btn.disabled=p.disponivel===false;btn.textContent=btn.disabled?'Indisponível':'Adicionar ao carrinho ↗';
    card.style.opacity=btn.disabled?'.65':'';card.dataset.crmProdutoId=String(p.id??'');
    gallery(card,p);
    const path = PRODUCT_PATHS[p.id];
    if(path && !document.body.dataset.productId){const link=document.createElement('a');link.href=path;link.textContent='Ver detalhes da coleção ↗';link.className='product-details-link';info.insertBefore(link,btn)}
    const note=document.createElement('small');note.className='product-note';note.textContent='Box com 4 copos · Sob encomenda';info.insertBefore(note,btn);
    if(document.body.dataset.productId){const heading=document.querySelector('h1');if(heading)heading.textContent=displayName;}
  }
  function createCard(p){
    const card=document.createElement('article');card.className='product-card';
    card.innerHTML='<div class="product-art cream"></div><div class="product-info"><h3></h3><div class="sample-price"></div><p></p><button type="button" class="small-btn add-to-cart">Adicionar ao carrinho ↗</button></div>';
    grid.append(card);updateCard(card,p);return card;
  }
  function updateClub(p){
    const duration=months(p);if(duration!==3&&duration!==6)return;
    const card=plans?.querySelector(`.club-add[data-product-duration="${duration}"]`)?.closest('.plan');if(!card)return;
    const amount=price(p.preco),btn=card.querySelector('.club-add');
    if(p.id)btn.dataset.productId=String(p.id);
    if(amount!==null){card.querySelector('.club-price').textContent=money(amount);btn.dataset.productPrice=amount.toFixed(2)}
    if(p.descricao)card.querySelector('.subtitle').textContent=p.descricao;
    btn.disabled=p.disponivel===false;btn.textContent=btn.disabled?'Plano indisponível':'Adicionar plano ao carrinho ↗';
    card.style.opacity=btn.disabled?'.65':'';card.dataset.crmProdutoId=String(p.id??'');
  }
  legacyCards.forEach(card=>{card.dataset.legacyProduct='1'});
  async function sync(){
    try{
      const res=await fetch('/api/admin-produtos?publico=1',{cache:'no-store'});
      if(!res.ok)throw Error('Catálogo HTTP '+res.status);
      const data=await res.json();if(!Array.isArray(data.produtos))throw Error('Resposta de catálogo inválida');
      const all=data.produtos.filter(p=>p&&typeof p.nome==='string');
      // A vitrine é 100% controlada pelo Supabase: nunca mantém anúncios antigos.
      grid.replaceChildren();
      const ativos=all.filter(p=>!isClub(p) && p.disponivel!==false && (!document.body.dataset.productId || String(p.id) === document.body.dataset.productId));
      ativos.sort((a,b)=>(Number(a.ordem)||0)-(Number(b.ordem)||0)||String(a.nome).localeCompare(String(b.nome),'pt-BR'));
      for(const p of ativos)createCard(p);
      for(const p of all.filter(isClub))updateClub(p);
      document.dispatchEvent(new CustomEvent('mimbox:catalog-ready', {detail: all}));
      if(!ativos.length){
        const aviso=document.createElement('p');
        aviso.textContent=document.body.dataset.productId?'Esta coleção não está disponível no momento. Conheça as outras boxes na loja.':'Novas coleções em preparação. Volte em breve!';
        aviso.className='catalog-empty';
        grid.append(aviso);
      }
    }catch(err){console.error('Falha ao consultar catálogo CRM:',err);grid.replaceChildren();const aviso=document.createElement('p');aviso.textContent='Não foi possível carregar as coleções agora. Atualize a página em instantes.';aviso.className='catalog-error';grid.append(aviso)}
  }
  sync();
})();
