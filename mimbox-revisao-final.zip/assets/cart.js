
(() => {
  const STORAGE_KEY = 'mimbox-cart-v1';
  let checkoutStep = 1;
  const panel = document.getElementById('cart-panel');
  const backdrop = document.getElementById('cart-backdrop');
  const itemsEl = document.getElementById('cart-items');
  const emptyEl = document.getElementById('cart-empty');
  const summaryEl = document.getElementById('cart-summary');
  const countEl = document.getElementById('cart-count');
  const subtotalEl = document.getElementById('cart-subtotal');
  let cart = [];
  let selectedFreight = null;
  let quoteRequestToken = 0;
  try { cart = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); if (!Array.isArray(cart)) cart = []; } catch (_) { cart = []; }

  const money = value => new Intl.NumberFormat('pt-BR', {style:'currency', currency:'BRL'}).format(value);
  const save = () => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(cart)); } catch (_) {} };
  cart = cart.filter(x => x && typeof x.id === 'string' && typeof x.name === 'string' && Number.isFinite(x.price) && x.price > 0 && Number.isInteger(x.qty) && x.qty > 0 && x.qty <= 20);
  const totalQty = () => cart.reduce((sum, item) => sum + item.qty, 0);
  const subtotal = () => cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  function render() {
    selectedFreight = null; quoteRequestToken++;
    const freightResults = document.getElementById('freight-results');
    if (freightResults) freightResults.replaceChildren();
    countEl.textContent = totalQty();
    emptyEl.hidden = cart.length > 0;
    summaryEl.hidden = cart.length === 0;
    itemsEl.innerHTML = '';
    cart.forEach(item => {
      const row = document.createElement('article');
      row.className = 'cart-item';
      const info = document.createElement('div');
      const title = document.createElement('h3'); title.textContent = item.name;
      const kindLabel = document.createElement('div'); kindLabel.className = 'cart-kind-label'; kindLabel.textContent = item.kind === 'club' ? 'Plano do clube' : 'Box avulsa';
      const meta = document.createElement('div'); meta.className = 'cart-item-meta'; meta.textContent = item.kind === 'club' ? (item.duration || 'Plano') + ' meses · pagamento único · frete incluso' : 'Box com 4 copos colecionáveis';
      const actions = document.createElement('div'); actions.className = 'cart-item-actions';
      const qty = document.createElement('div'); qty.className = 'cart-qty';
      const minus = document.createElement('button'); minus.type='button'; minus.textContent='−'; minus.setAttribute('aria-label','Diminuir quantidade');
      minus.addEventListener('click', () => changeQty(item.id, -1));
      const q = document.createElement('span'); q.textContent=item.qty;
      const plus = document.createElement('button'); plus.type='button'; plus.textContent='+'; plus.setAttribute('aria-label','Aumentar quantidade');
      plus.addEventListener('click', () => changeQty(item.id, 1));
      qty.append(minus,q,plus);
      const remove = document.createElement('button'); remove.className='cart-remove'; remove.type='button'; remove.textContent='Remover';
      remove.addEventListener('click', () => { cart=cart.filter(x=>x.id!==item.id); save(); render(); });
      actions.append(qty,remove);
      info.append(title,kindLabel,meta,actions);
      const price = document.createElement('div'); price.className='cart-item-price'; price.textContent=money(item.price*item.qty);
      row.append(info,price); itemsEl.append(row);
    });
    subtotalEl.textContent = money(subtotal());
    updateCheckoutFormVisibility();
  }

  function changeQty(id, delta) {
    const item = cart.find(x=>x.id===id);
    if (!item) return;
    if (item.qty + delta > 20) return;
    item.qty += delta;
    if (item.qty <= 0) cart = cart.filter(x=>x.id!==id);
    save(); render();
  }
  function openCart() {
    panel.hidden=false; backdrop.hidden=false; document.body.style.overflow='hidden';
    document.querySelectorAll('body > :not(#cart-panel):not(#cart-backdrop):not(script)').forEach(el => { if (!el.inert) { el.inert = true; el.dataset.cartInert = '1'; } });
    document.getElementById('close-cart').focus();
    const content = panel.querySelector('.cart-content');
    if (content) content.scrollTop = 0;
  }
  function closeCart() {
    panel.hidden=true; backdrop.hidden=true; document.body.style.overflow='';
    document.querySelectorAll('[data-cart-inert]').forEach(el => { el.inert = false; delete el.dataset.cartInert; });
    document.getElementById('open-cart').focus();
  }
  function addProduct(button) {
    const id=button.dataset.productId, name=button.dataset.productName, price=Number(button.dataset.productPrice);
    const kind=button.dataset.productKind || 'box';
    const duration=button.dataset.productDuration || '';
    if (!id || !name || !Number.isFinite(price) || price <= 0) return;
    const existing=cart.find(x=>x.id===id);
    if (existing) { if(existing.qty >= 20) return; existing.qty += 1; }
    else cart.push({id,name,price,qty:1,kind,duration});
    checkoutStep = 1;
    checkoutForm.hidden = true;
    save(); render(); openCart();
  }

  // Delegação: funciona também se os botões forem recriados na página.
  document.addEventListener('click', event => {
    const target = event.target instanceof Element ? event.target : event.target?.parentElement;
    if (!target) return;
    const addButton = target.closest('.add-to-cart, [data-product-id][data-product-price]');
    if (addButton) { event.preventDefault(); addProduct(addButton); return; }
    if (target.closest('#open-cart')) { event.preventDefault(); openCart(); return; }
    if (target.closest('#close-cart, #cart-backdrop')) { event.preventDefault(); closeCart(); }
  });
  document.getElementById('continue-shopping').addEventListener('click', () => { closeCart(); const boxes=document.getElementById('boxes'); if(boxes)boxes.scrollIntoView({behavior:'smooth'});else window.location.assign('/#boxes'); });
  document.getElementById('clear-cart').addEventListener('click', () => { cart=[]; save(); render(); });
  const checkoutForm = document.getElementById('cart-checkout-form');
  const checkoutButton = document.getElementById('cart-checkout');
  function cartHasClubPlan() {
    return cart.some(item => item.kind === 'club');
  }
  function updateCheckoutFormVisibility() {
    if (cart.length === 0) checkoutStep = 1;
    checkoutForm.hidden = checkoutStep !== 2;
    document.getElementById('cart-items').hidden = checkoutStep === 2;
    document.getElementById('cart-empty').hidden = checkoutStep === 2 || cart.length > 0;
    document.getElementById('checkout-steps').textContent = checkoutStep === 1 ? '1. Pedido  →  2. Recebimento  →  3. Pagamento' : '✓ Pedido  →  2. Recebimento  →  3. Pagamento';
    checkoutButton.hidden = checkoutStep === 2;
    checkoutButton.textContent = 'Continuar para recebimento →';
    checkoutButton.disabled = cart.length === 0;
    const clubFields = document.getElementById('club-preferences-fields');
    if (clubFields) clubFields.hidden = !cartHasClubPlan();
  }

  document.getElementById('cart-checkout').addEventListener('click', () => {
    if (!cart.length) return;
    checkoutStep = 2;
    updateCheckoutFormVisibility();
    document.querySelector('#cart-panel .cart-content').scrollTop = 0;
  });
  document.getElementById('checkout-back').addEventListener('click', () => {
    checkoutStep = 1;
    updateCheckoutFormVisibility();
  });

  const deliveryMethod = document.getElementById('delivery-method');
  const pickupNote = document.getElementById('pickup-note');
  const addressFields = [
    document.getElementById('checkout-cep'),
    document.getElementById('checkout-street'),
    document.getElementById('checkout-number'),
    document.getElementById('checkout-neighborhood'),
    document.getElementById('checkout-city'),
    document.getElementById('checkout-state')
  ];
  function updateDeliveryMethod() {
    const pickup = deliveryMethod.value === 'pickup';
    selectedFreight = null; quoteRequestToken++;
    const freightResults = document.getElementById('freight-results');
    if (freightResults) freightResults.textContent = '';
    document.getElementById('shipping-status').textContent = pickup ? 'Retirada grátis — Rua Américo Brasiliense, 2078, Chácara Santo Antônio, São Paulo/SP. Terça a quinta, 10h–18h.' : 'Informe o CEP para consultar transportadoras. Frete grátis em compras acima de R$ 300.';
    freightOptions.hidden = pickup;
    pickupNote.hidden = !pickup;
    document.getElementById('checkout-address-fields').hidden = pickup;
    addressFields.forEach(field => {
      field.required = !pickup;
      field.disabled = pickup;
    });
    document.getElementById('cep-status').textContent = pickup
      ? 'Retirada selecionada: não é necessário informar o CEP.'
      : 'Digite o CEP para preencher rua, bairro e cidade.';
  }
  const freightOptions = document.getElementById('freight-options');
  const originalUpdateDeliveryMethod = updateDeliveryMethod;
  deliveryMethod.addEventListener('change', updateDeliveryMethod);
  updateDeliveryMethod();

  document.getElementById('quote-freight').addEventListener('click', async () => {
    const cep = document.getElementById('checkout-cep').value.replace(/\D/g, '');
    const results = document.getElementById('freight-results');
    if (!/^\d{8}$/.test(cep)) { results.textContent = 'Digite um CEP válido com 8 números.'; return; }
    const requestToken = ++quoteRequestToken;
    const quoteButton = document.getElementById('quote-freight');
    quoteButton.disabled = true;
    results.textContent = 'Consultando transportadoras…';
    selectedFreight = null;
    try {
      const response = await fetch('/api/calcular-frete', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cep, itemCount: cart.reduce((sum, item) => sum + Number(item.qty || 1), 0), subtotal: Math.round(subtotal() * 100) })
      });
      const data = await response.json();
      if (requestToken !== quoteRequestToken) return;
      if (!response.ok) throw new Error(data.error || 'Não foi possível consultar o frete.');
      const options = Array.isArray(data) ? data : (data.opcoes || data.options || data.services || data.quotes || []);
      const valid = options.filter(x => x && !x.error && Number.isFinite(Number(x.valor ?? x.custom_price ?? x.price)));
      if (!valid.length) { results.textContent = 'Nenhuma transportadora disponível para esse CEP.'; return; }
      results.replaceChildren();
      valid.forEach((option, i) => {
        const label = document.createElement('label');
        label.style.cssText = 'display:block;padding:10px;border:1px solid #ddd;border-radius:8px;margin:6px 0;cursor:pointer';
        const radio = document.createElement('input'); radio.type = 'radio'; radio.name = 'freight-service'; radio.value = String(option.id ?? i);
        radio.addEventListener('change', () => { selectedFreight = { id: option.id, price: (subtotal() > 300 || cart.every(item => item.kind === 'club')) ? 0 : Number(option.valor ?? option.custom_price ?? option.price), cep, name: option.servico ?? option.name, company: option.transportadora ?? option.company?.name }; });
        const includesFreight = subtotal() > 300 || cart.every(item => item.kind === 'club');
        const price = includesFreight ? 0 : Number(option.valor ?? option.custom_price ?? option.price);
        const name = [option.transportadora || option.company?.name || option.company, option.servico || option.name].filter(x => typeof x === 'string').join(' — ');
        const days = option.prazo ?? option.custom_delivery_time ?? option.delivery_time;
        label.append(radio, document.createTextNode(' ' + (name || 'Transportadora') + ' · R$ ' + price.toFixed(2).replace('.', ',') + (days ? ' · ' + days + ' dias úteis de transporte + até 7 dias úteis de produção' : '')));
        results.append(label);
      });
      const info = document.createElement('p'); info.textContent = 'O valor definitivo será validado antes do pagamento.'; results.append(info);
    } catch (error) { if (requestToken === quoteRequestToken) results.textContent = error.message || 'Erro ao consultar frete.'; }
    finally { quoteButton.disabled = false; }
  });

  // Consulta pública dos Correios via ViaCEP; endereço continua editável pelo cliente.
  const cepInput = document.getElementById('checkout-cep');
  const cepStatus = document.getElementById('cep-status');
  let cepRequestToken = 0;
  cepInput.addEventListener('input', () => {
    const digits = cepInput.value.replace(/\D/g, '').slice(0, 8);
    cepInput.value = digits.length > 5 ? digits.slice(0,5) + '-' + digits.slice(5) : digits;
    selectedFreight = null; quoteRequestToken++;
    document.getElementById('freight-results').textContent = '';
    const token = ++cepRequestToken;
    if (digits.length !== 8) {
      cepStatus.textContent = 'Digite os 8 números do CEP para buscar o endereço.';
      return;
    }
    cepStatus.textContent = 'Buscando endereço…';
    fetch('https://viacep.com.br/ws/' + digits + '/json/')
      .then(response => { if (!response.ok) throw new Error('Falha na consulta'); return response.json(); })
      .then(result => {
        if (token !== cepRequestToken) return;
        if (result.erro) { cepStatus.textContent = 'CEP não encontrado. Confira os números ou preencha manualmente.'; return; }
        const street = document.getElementById('checkout-street');
        const neighborhood = document.getElementById('checkout-neighborhood');
        const city = document.getElementById('checkout-city');
        const state = document.getElementById('checkout-state');
        street.value = result.logradouro || '';
        neighborhood.value = result.bairro || '';
        city.value = result.localidade || '';
        state.value = result.uf || '';
        cepStatus.textContent = 'Endereço localizado. Confira e complete o número.';
        if (!street.value) street.focus();
        else document.getElementById('checkout-number').focus();
      })
      .catch(() => { if (token === cepRequestToken) cepStatus.textContent = 'Não foi possível consultar agora. Preencha o endereço manualmente.'; });
  });

  // Checkout integrado à API segura hospedada no Vercel.
  // Os preços são validados novamente no servidor; os valores do navegador não são confiáveis.
  // Máscara e validação de telefone brasileiro: DDD obrigatório + 10 ou 11 dígitos.
  const phoneInput = document.getElementById('checkout-phone');
  const phoneStatus = document.getElementById('phone-status');
  function formatBrazilPhone(value) {
    const digits = value.replace(/\D/g, '').slice(0, 11);
    if (!digits) return '';
    if (digits.length < 3) return '(' + digits;
    const ddd = digits.slice(0, 2);
    const rest = digits.slice(2);
    if (rest.length <= 4) return '(' + ddd + ') ' + rest;
    if (rest.length <= 8) return '(' + ddd + ') ' + rest.slice(0, 4) + '-' + rest.slice(4);
    return '(' + ddd + ') ' + rest.slice(0, 5) + '-' + rest.slice(5, 9);
  }
  phoneInput.addEventListener('input', () => {
    phoneInput.value = formatBrazilPhone(phoneInput.value);
    const digits = phoneInput.value.replace(/\D/g, '');
    phoneInput.setCustomValidity('');
    phoneStatus.textContent = (digits.length === 10 || digits.length === 11)
      ? 'Telefone com DDD preenchido.'
      : 'Inclua o DDD e o número: 10 ou 11 dígitos no total.';
  });
  phoneInput.addEventListener('blur', () => {
    const digits = phoneInput.value.replace(/\D/g, '');
    if (digits.length !== 10 && digits.length !== 11) {
      phoneInput.setCustomValidity('Informe o DDD e um telefone válido com 10 ou 11 dígitos.');
      phoneStatus.textContent = 'Telefone incompleto: informe DDD + número.';
    } else {
      phoneInput.setCustomValidity('');
    }
  });

  function showCheckoutMessage(message) {
    let toast = document.querySelector('.cart-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'cart-toast';
      toast.setAttribute('role', 'status');
      document.body.append(toast);
    }
    toast.textContent = message;
    window.setTimeout(() => toast.remove(), 6000);
  }

  checkoutForm.addEventListener('submit', async event => {
    event.preventDefault();
    if (!cart.length) {
      showCheckoutMessage('Seu carrinho está vazio.');
      return;
    }


    if (deliveryMethod.value === 'shipping') {
      const currentCep = document.getElementById('checkout-cep').value.replace(/\D/g, '');
      if (!selectedFreight || selectedFreight.cep !== currentCep) {
        showCheckoutMessage('Calcule o frete e selecione uma transportadora antes de pagar.');
        return;
      }
    }
    const submitButton = checkoutForm.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.disabled = true;
    submitButton.textContent = 'Gerando pagamento…';

    const valueOf = name => (checkoutForm.elements.namedItem(name)?.value || '').trim();
    const digits = valueOf('customerPhone').replace(/\D/g, '');
    const payload = {
      items: cart.map(item => ({
        id: String(item.id || ''),
        description: String(item.name || ''),
        quantity: Number(item.qty)
      })),
      customer: {
        name: valueOf('customerName'),
        email: valueOf('customerEmail'),
        phone_number: '+55' + digits
      },
      address: {
        cep: valueOf('cep').replace(/\D/g, ''),
        street: valueOf('street'),
        neighborhood: valueOf('neighborhood'),
        number: valueOf('number'),
        complement: valueOf('complement'),
        city: valueOf('city'),
        state: valueOf('state').toUpperCase()
      },
      deliveryMethod: deliveryMethod.value,
      shippingServiceId: deliveryMethod.value === 'shipping' ? selectedFreight.id : undefined,
      preferences: valueOf('preferences'),
      avoid: valueOf('avoid')
    };

    try {
      const response = await fetch('/api/criar-checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(result.error || 'Não foi possível gerar o pagamento. Confira os dados e tente novamente.');
      }
      const paymentUrl = result.url || result.checkout_url || result.payment_url || result.link;
      if (!paymentUrl || typeof paymentUrl !== 'string' || !/^https:\/\/[^ ]+/i.test(paymentUrl)) {
        throw new Error('A InfinitePay respondeu, mas não recebemos um link de pagamento válido. Nenhuma cobrança foi confirmada.');
      }
      window.location.assign(paymentUrl);
    } catch (error) {
      showCheckoutMessage(error.message || 'Falha ao conectar à InfinitePay. Tente novamente.');
      submitButton.disabled = false;
      submitButton.textContent = originalText;
    }
  });
  document.addEventListener('keydown', e => { if (e.key==='Escape' && !panel.hidden) closeCart(); });
  document.addEventListener('keydown', e => {
    if (e.key !== 'Tab' || panel.hidden) return;
    const nodes = [...panel.querySelectorAll('button,input,select,textarea,a[href]')].filter(el => !el.disabled && el.getClientRects().length);
    const first=nodes[0], last=nodes[nodes.length-1];
    if(e.shiftKey && document.activeElement===first){e.preventDefault();last?.focus()}
    else if(!e.shiftKey && document.activeElement===last){e.preventDefault();first?.focus()}
  });
  render();
})();
