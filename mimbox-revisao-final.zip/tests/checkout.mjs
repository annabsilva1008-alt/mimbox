import fs from 'node:fs/promises';import assert from 'node:assert/strict';
const source=await fs.readFile(new URL('../api/criar-checkout.js', import.meta.url),'utf8');const {default:handler}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
process.env.SUPABASE_URL='https://db.test';process.env.SUPABASE_SECRET_KEY='test-only';process.env.MELHOR_ENVIO_TOKEN='test-only';
const id='72eae3cd-e308-4971-a5c8-4448d105487e';let calls=[],saved,failDb=false,emptyDb=false;
globalThis.fetch=async(url,options={})=>{const body=options.body?JSON.parse(options.body):null;calls.push({url,body});let data=[];
 if(url.includes('/produtos?'))data=[{id,nome:'Brasilidades',preco:59.9,disponivel:true}];
 else if(url.includes('/clientes?'))data=[{id:'customer-id'}];
 else if(url.includes('/pedidos?')&&options.method==='POST'){saved=body;if(failDb)return{ok:false,status:503,json:async()=>({})};data=emptyDb?[]:[{id:'order-id'}]}
 else if(url.includes('shipment/calculate'))data=[{id:1,name:'PAC',company:{name:'Correios'},price:'20.00',delivery_time:5}];
 else if(url.endsWith('/links'))data={url:'https://checkout.infinitepay.io/test'};
 return{ok:true,status:200,json:async()=>data};};
async function run(overrides={}){calls=[];saved=null;let status=200,result;const res={setHeader(){},status(s){status=s;return this},json(d){result=d;return this}};await handler({method:'POST',body:{items:[{id,quantity:1}],customer:{name:'Cliente Teste',email:'test@example.com',phone_number:'+5511999999999'},deliveryMethod:'pickup',...overrides}},res);return {status,result};}
let r=await run();assert.equal(r.status,200);assert.equal(saved.valor_total,59.9);assert.equal(saved.status_pagamento,'pendente');assert.ok(calls.findIndex(c=>c.url.includes('/pedidos?'))<calls.findIndex(c=>c.url.endsWith('/links')));
r=await run({items:[{id:'clube-3-meses',quantity:1}],deliveryMethod:'shipping',shippingServiceId:1,address:{cep:'01001000',street:'Rua',number:'1',neighborhood:'Centro',city:'São Paulo',state:'SP'},preferences:'Gosto de azul',avoid:'Rosa'});assert.equal(r.status,200);assert.equal(saved.valor_total,299.9);assert.equal(saved.frete_valor,0);assert.equal(saved.tipo,'clube');assert.match(saved.observacoes,/Gosto de azul/);assert.match(saved.observacoes,/Rosa/);
r=await run({deliveryMethod:'shipping',shippingServiceId:1,address:{cep:'01001000',street:'Rua',number:'1',neighborhood:'Centro',city:'São Paulo',state:'SP'}});assert.equal(saved.valor_total,79.9);assert.equal(saved.frete_valor,20);
r=await run({items:[{id:'clube-6-meses',quantity:1}]});assert.equal(saved.valor_total,549.9);
r=await run({items:[{id,quantity:21}]});assert.equal(r.status,400);assert.ok(!calls.some(c=>c.url.endsWith('/links')));
failDb=true;r=await run();assert.equal(r.status,503);assert.ok(!calls.some(c=>c.url.endsWith('/links')));failDb=false;
emptyDb=true;r=await run();assert.equal(r.status,503);assert.ok(!calls.some(c=>c.url.endsWith('/links')));emptyDb=false;
console.log('PASS: CRM antes do pagamento, preço validado, frete pago/grátis, planos, preferências, quantidades inválidas e bloqueio quando o CRM falha.');
